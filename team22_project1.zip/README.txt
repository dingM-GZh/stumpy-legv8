team22_project1.py

Clayton Stamper - c_s449
Maxwell Ding    - m_d339

To run this file in Linux, use the command "python"
1.) Type in "python"
    (Do not hit enter, there is more to be added)

2.) Add "-i" for input, followed by the input file name 
    (Be sure to add the file extension, i.e. '.txt')

3.) Add "-o" for output, followed by the output file name
    (The name of the file to be created, must also include file extension)

4.) Enter the command

Sample = 
$ python -i inputFile.txt -o outputFile.txt