team22_project1.py

Clayton Stamper - c_s449
Maxwell Ding    - m_d339

To run this file in Linux, use the command "python"
1.) Type in "python"
    (Do not hit enter, there is more to be added)

2.) Add the name of the file, with the .py file extension
    (team22_project1.py)

3.) Add "-i" for input, followed by the input file name 
    (Be sure to add the file extension, i.e. '.txt')

4.) Add "-o" for output, followed by the output file name
    (The name of the file to be created, do not need to enter file extension)

5.) Enter the command
    (Hit enter)

Sample = 
 python team22_project.py -i inputFile.txt -o outputFile