team22_project1.py

Hi Greg, our project 3 is incomplete. We'll turn in what we have and will continue to work on it but understand that you've already given us plenty of time and don't have any excuses for not having the project.

See lines 433 and lines 640 to see what we have planned going forward. I'll send you our finished project within the next couple days,

Thanks,

- Clayton Stamper

Clayton Stamper - c_s449
Maxwell Ding    - m_d339

To run this file in Linux, use the command "python"
1.) Type in "python"
    (Do not hit enter, there is more to be added)

2.) Add the name of the file, with the .py file extension
    (team22_project1.py)

3.) Add "-i" for input, followed by the input file name 
    (Be sure to add the file extension, i.e. '.txt')

4.) Add "-o" for output, followed by the output file name
    (The name of the file to be created, do not need to enter file extension)

5.) Enter the command
    (Hit enter)

Sample = 
 python team22_project.py -i inputFile.txt -o outputFile
